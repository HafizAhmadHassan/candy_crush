#include <iostream>
#include "HugeInt.h"

using namespace std;

//*****HELPER FUNCTIONS*****
int* hugeInt::getptr(){

	return ptr;
}
int hugeInt::get_maxSize(){

	return maxSize;
}
int hugeInt::breakInt(int x,int *arr){

	int count=0;
	
	while(x>=10){
	
		arr[count++]=x%10;
		x/=10;
	}
	if(x<10)
		arr[count]=x;

	return count+1;
}
void hugeInt::incArray(){

	int *p=new int[maxSize+1];

	for(int i=maxSize;i>=0;i--)
		p[i]=ptr[i-1];

	maxSize++;

	delete []ptr;
	ptr=p;
	p=nullptr;
}
void hugeInt::orderCorrect(int arr[],int x){

	int z=x-1;
	for(int i=0;i<=z/2;i++,z--)
		swap(arr[i],arr[z]);

}
void hugeInt::setter_maxSize(int x){

	maxSize=x;
}
void hugeInt::setterPtr(int x){

	delete []ptr;
	ptr=new int[x];
}

//*****Arthimetic Operators*****

//subtraction with a integer
hugeInt& hugeInt::operator-(int x){

	int arr[10];
	int count=breakInt(x,arr);	
	orderCorrect(arr,count);
	
	int index =maxSize-1;
	for(int i=count-1;i>=0;i--,index--){
	
		if(count>maxSize){
		
			delete []ptr;
			ptr=new int[1];
			ptr[0]=-1;
			maxSize=1;
		}

		if(ptr[index] < arr[i]){
			
			if(ptr[index]==0)
				ptr[index]=10;				
			else
				ptr[index]=ptr[index]+10;
			
			
			int u=0;
			int f=0;
		
			while(u==0){
				f++;
				u=ptr[index-f];
			}
			ptr[index-f]--;
			for(int l=f-1;l>0;l--)
				ptr[index-l]=9;

			if(f==1 && (u>9 || u<1) ){
			
				//delete []ptr;
				ptr=new int[1];
				ptr[0]=-1;
				maxSize=1;
				break;
			}
		}

		ptr[index]-=arr[i];

	}
	int f=maxSize-1;

	while(ptr[0]==0 && maxSize>1){
		int l=maxSize-2;
		int *p=new int[maxSize-1];
		for(int f=maxSize-1;f>=1;f--){
			p[l]=ptr[f];
			l--;
		}
		maxSize--;
		delete []ptr;
		ptr=p;
		p=nullptr;
	}

	return *this;
}

//addition with a integer
void hugeInt::adding(int num,int index){

	
}
hugeInt& hugeInt::operator+(int x){

	int arr[10];
	int count=breakInt(x,arr);
	orderCorrect(arr,count);
	int index =maxSize-1;
	bool inc=false;
	count--;
	int c=count;
	for(int i=c;i>=0;i--){
		if(ptr[index]+arr[count]<=9)
	
			ptr[index]=ptr[index]+arr[count];

		else{
			int temp=ptr[index]+arr[count];
			if(index==0){
				incArray();
				ptr[index]=0;
				index++;
				inc=true;
			}
			ptr[index]=temp%10;
			ptr[index-1]+=1;
			int u=index-1;
			while(ptr[u]>9){
			
				ptr[u]%=10;
				ptr[u-1]+=1;
				u--;
			}
			if(inc==true){
			
				index--;
				inc=false;
			}
		}
		c--;
		index--;
	}

	return *this;
}

//multiplication with a integer
hugeInt& hugeInt::operator*(int x){

	hugeInt temp=*this;
	for(int i=1 ;i<x;i++)
		*this=operator+(temp);
	
	return *this;
}

//division with a integer
int hugeInt::operator/(int x){

	int count=0;
	while(ptr[0]>0){
		
		operator-(x);
		count++;
		if(ptr[0]==-1)
			count--;
	}
	return count;
}

//subtraction with a hugeInt object90
hugeInt& hugeInt::operator-(hugeInt &obj){

	int j;
	if(maxSize<obj.maxSize){
		j=obj.maxSize-1;
		for(int i=maxSize-1;i>=0;i--){
	
			if(ptr[i] < obj.ptr[j]){
			
				if(ptr[i]!=0)
					ptr[i]+=10;
				else
					ptr[i]=10;
				int u=0;
				int f=0;
				while(u==0){
					
					f++;
					u=ptr[j-f];
				}
				u=f;
				ptr[j-f]--;
				for(int l=f-1;l>0;l--)
					ptr[j-l]=9;
				
			}
			obj.ptr[j]-=ptr[i];
			j--;
		}
	}
	else{
		j=maxSize-1;
		for(int i=obj.maxSize-1;i>=0;i--){
			if(ptr[j] < obj.ptr[i]){
				if(ptr[j]!=0)
					ptr[j]+=10;
				else
					ptr[j]=10;
				
			int u=0;
			int f=0;
			while(u==0){
					
				f++;
				u=ptr[j-f];
			}
			u=f;
			ptr[j-f]--;
			for(int l=f-1;l>0;l--)
				ptr[j-l]=9;
			}
		
			ptr[j]-=obj.ptr[i];
			j--;
		}
	}
	int f=maxSize-1;
		
	while(ptr[0]==0 && maxSize>1){
		int l=maxSize-2;
		int *p=new int[maxSize-1];
		for(f=maxSize-1;f>=1;f--){
			p[l]=ptr[f];
			l--;
		}
		maxSize--;
		delete []ptr;
		ptr=p;
		p=nullptr;
	}
	return*this;
}
//addition with a hugeInt object
hugeInt& hugeInt::operator+(hugeInt &obj){
	
	bool check=false;
	int count;
	if(obj.maxSize<this->maxSize){
		count=obj.maxSize-1;
		check=true;
	}
	else
		count=this->maxSize-1;
	
	if(obj.maxSize<this->maxSize){

		int j=maxSize-1;

		for(int i=count;i>=0 ;i--){

			if(this->ptr[j] + obj.ptr[i] > 9){
				
				int temp=this->ptr[j] + obj.ptr[i];
				ptr[j]=temp%10;
				ptr[j-1]+=1;
				
			}
			else
				this->ptr[j] += obj.ptr[i];
			j--;
		}
		
		return *this;
	}
	
	else if(obj.maxSize>this->maxSize){

		int j=maxSize;

		for(int i=count;i>=0 ;i--){

			if(this->ptr[j] + obj.ptr[i] > 9){
				
				int temp=this->ptr[j] + obj.ptr[i];
				obj.ptr[j]=temp%10;
				obj.ptr[j-1]=1;
				
			}
			else
				obj.ptr[j] += ptr[i];
			j--;
		}
		
		return obj;
	}
	else{

		int j=obj.maxSize-1;

		for(int i=count;i>=0 ;i--){
	
			if(this->ptr[i] + obj.ptr[j] > 9){
				if(j!=0){
					int x=this->ptr[i] + obj.ptr[j];
				
					ptr[j]=x%10;
					ptr[j-1]+=1;
				}
				else{

					int *p=new int[maxSize+1];

					for(int f=maxSize;f>=0;f--){
						p[f]=ptr[f-1];
					}
					p[0]=0;
					maxSize++;

					delete []ptr;
					ptr=p;
					p=nullptr;

					p=new int[obj.maxSize+1];

					for(int f=obj.maxSize;f>=0;f--){
						p[f]=obj.ptr[f-1];
					}
					p[0]=0;
					obj.maxSize++;

					delete []obj.ptr;
					obj.ptr=p;
					p=nullptr;
				
					int temp=this->ptr[i+1] + obj.ptr[j+1];
					ptr[j+1]=temp%10;
					ptr[j]=1;
				}
			}
			else 
				ptr[j] +=obj.ptr[i];

			j--;
		}
			return *this;
	}
}


//multiplication with a hugeInt object

hugeInt& hugeInt::operator*(hugeInt &obj){

	hugeInt temp=*this;
	long long mul=1;
	for(int k=obj.maxSize-1;k>=0;k--){
		int x=obj.ptr[k]*mul;
		for(int i=1 ;i<x;i++){
	
			*this=operator+(temp);
		}
		mul*=10;
		if(k!=0)
		*this=operator+(temp);
	}
	return *this;
}

//division with a hugeInt object
int hugeInt::operator/(hugeInt &obj){
	
	int i=0;
	int count=0,x=0;
	int mul=1;
	for(int k=obj.maxSize-1;k>=0;k--){
		x=x+(obj.ptr[k]*mul);
		mul*=10;
	}
	
	while(ptr[0]>0){
		
		operator-(x);
		count++;
		if(ptr[0]==-1)
			count--;
	}
	
	return count;
}

hugeInt& hugeInt::operator=(hugeInt &obj){

	int *p=new int[maxSize];
	maxSize=obj.maxSize;
	
	for(int i=0;i<obj.maxSize;i++){
	
		p[i]=obj.ptr[i];
	}
	delete[] ptr;
	ptr=p;
	p = nullptr;
	return *this;
}

//*****Logical Operators*****

//equality operator
bool hugeInt::operator==(hugeInt &obj){

	if(maxSize!=obj.maxSize)
		return false;
	else{
	
		for(int i=0;i<maxSize;i++){
		
			if(ptr[i]!=obj.ptr[i])
				return false;
		}
	}
	return true;
}

//inequality operator
bool hugeInt::operator!=(hugeInt &obj){

	if(maxSize!=obj.maxSize)
		return true;
	else{
	
		for(int i=0;i<maxSize;i++){
		
			if(ptr[i]!=obj.ptr[i])
				return true;
		}
	}
	return false;

}

//less then operator
bool hugeInt::operator<(hugeInt &obj){


	if(maxSize<obj.maxSize)
		return true;

	else if(maxSize>obj.maxSize)
		return false;
	
	else if(maxSize==obj.maxSize){
	
		if(*this==obj)
			return false;
		
		else{
		
			for(int i=0;i<maxSize;i++){
		
				if(ptr[i]>obj.ptr[i])
					return false;
			}
		}
	}
	return true;
}

//less then or equal to operator 
bool hugeInt::operator<=(hugeInt &obj){

	if(*this == obj || *this < obj)
		return true;
	else 
		return false;
}

//greater then operator
bool hugeInt:: operator>(hugeInt &obj){

	if(maxSize>obj.maxSize)
		return true;

	else if(maxSize<obj.maxSize)
		return false;
	
	else if(maxSize == obj.maxSize){
	
		if(*this == obj)
			return false;
		
		else{
		
			for(int i=0;i<maxSize;i++){
		
				if(ptr[i]<obj.ptr[i])
					return false;
			}
		}
	}
	return true;
}

//greater then or equal to operator
bool hugeInt::operator>=(hugeInt &obj){

	if(*this == obj || *this > obj)
		return true;
	else 
		return false;
}


//*****Stream Operators*****

//input operator
istream& operator>>(istream& in,hugeInt& obj){

	int size=64,set=0;
	char *inputArr=new char[64];
	
	cin.getline(inputArr,63);
	

	obj.setterPtr(strlen(inputArr) );
	int *ptr=obj.getptr();
 	
	for(int j=0;inputArr[j]!='\0';j++){
		
		ptr[j]=inputArr[j]-48;
		set=j;
	}
	
	obj.setter_maxSize(set+1);
	delete []inputArr;
	return in;
}

//output operator
ostream& operator<<(ostream &out,hugeInt& obj){

	int *ptr=obj.ptr;

	for(int i=0;i<obj.get_maxSize();i++)
		out<<ptr[i];

	return out;
}



//*****constructors*****

//default constructor
hugeInt::hugeInt(){

	ptr=new int[1];
	maxSize=1;
	ptr[0]=0;

}

//parameterized constructor
hugeInt::hugeInt(int x){

	ptr=new int[10];
	maxSize=breakInt(x,ptr);
	orderCorrect(ptr,maxSize);
}

//copy constructor
hugeInt::hugeInt( hugeInt &obj){

	ptr=new int[obj.maxSize];
	for(int i=0;i<obj.maxSize;i++)
		ptr[i]=obj.ptr[i];
	maxSize=obj.maxSize;
}

//*****destructor*****
hugeInt::~hugeInt(){

	if(ptr != nullptr)
		delete []ptr;
}


/*
		if(count > maxSize)
			ptr[index]=0;
		else if(count == maxSize){
			int p=0;
			bool flag=true;
			while(flag == true && p<=count){
				if(ptr[p]<arr[p]){
					flag=false;
				}
				else{
					p++;
				}
			}
			if(flag == false)
				ptr[0]=0;
		}*/