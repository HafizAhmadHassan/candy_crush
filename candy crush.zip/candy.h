#include <iostream>
using namespace std;
class candy{

public:

	int id;
	int size;
	int stripes;

	candy(){
	
		id=0;
		size=0;
		stripes=0;
	}
	int get_id(){
	
		return id;
	}
	int get_size(){
	
		return size;
	}
	void setter(){
	
		id=0;
		size=0;
		stripes=0;
	}
	candy(int i,int s,int st){
	
		id=i;
		size=s;
		stripes=st;
	}
	virtual void enlarge(){}
	virtual void print(){}
	int sum_of_stripes(candy a,candy b){}
};
class orange:public candy{

public:

	orange(int i,int s,int st):candy(i,s,st){
	}
	
	void enlarge(candy a,candy b){
	
		size= size+a.size+b.size;	
	}
	void print(){
	
		cout<<"Orange Candy Is Added\n";
	}
};
class strawberry:public candy{

public:

	strawberry(int i,int s,int st):candy(i,s,st){
	}
	void print(){
	
		cout<<"Strawberry Candy Is Added\n";
	}
	void enlarge(candy a,candy b){

		size= size*a.size*b.size;
	}
};
class lemon:public candy{

public:

	lemon(int i,int s,int st):candy(i,s,st){
	}
	
	void enlarge(candy a,candy b){

		id=1;
		size= size+a.size+b.size+5;
	}
	void print(){
	
		cout<<"Lemon Candy Is Added\n";
	}
};
class chocolate:public candy{

public:

	chocolate(int i,int s,int st):candy(i,s,st){
	}
	
	void enlarge(candy a,candy b){
	
		size= (size+a.size+b.size)/3;	
	}
	void print(){
	
		cout<<"Chocalate Candy Is Added\n";
	}
};
class special_strawberry:public candy{

public:

	special_strawberry(int i,int s,int st):candy(i,s,st){
	}
	
	void enlarge(candy a,candy b){
		
		stripes=sum_of_stripes(a,b);
		size= (size*a.size*b.size)+sum_of_stripes(a,b);	
	}
	void print(){
	
		cout<<"Stripes Strawberry Is Candy Added\n";
	}
};
class special_orange:public candy{

public:

	special_orange(int i,int s,int st):candy(i,s,st){
	}
	
	void enlarge(candy a,candy b){
	
		stripes=0;
		size= size+a.size+b.size+sum_of_stripes(a,b);	
	}
	void print(){
	
		cout<<"Stripes Orange Candy Is Added\n";
	}
};
