#include <iostream>
#include "candy.h"

using namespace std;
class player{

private:

	int id;
	int score;
	int grid_rows;
	int grid_cols;
	
public:
		
	void print_grid(candy **candy_grid){
		for(int i=0;i<grid_rows;i++){
			for(int j=0;j<grid_cols;j++){
				int m=candy_grid[i][j].get_id();
				char ch;
				if(m==1)
					ch='O';
				else if(m==2)
					ch='S';
				else if(m==3)
					ch='L';
				else if(m==4)
					ch='C';
				else if(m==5)
					ch='+';
				else if(m==6)
					ch='#';
				cout<<ch<<"     ";
			}
			cout<<endl<<endl<<endl;
		}
		cout<<endl<<endl<<endl;
	}
	void update_score(int r1,int c1,candy **candy_grid){
	
		score+=candy_grid[r1][c1].get_size();
	}
	int get_score(){
	
		return score;
	}
	void set_score(int s){
	
		score=s;
	}
	bool swap(int r,int c,int r1,int c1,candy *arr[],bool auto_c,candy **candy_grid){

		bool swaping = false;
		r--;
		c--;
		r1--;
		c1--;
	
			if( check_consective_3(r,c,r1,c1,arr,auto_c,candy_grid) ==true){
		
				swaping= true;
			}	
		
		if(swaping == true){
			
			place_candy(r,c,r1,c1,candy_grid);
			big_candy(r1,c1,arr,candy_grid);
		}
		
		return swaping;
	}

	void auto_check(int r,int c,int r1,int c1,candy *arr[],bool auto_c,candy **candy_grid){
		bool check = true;

		while(check == true){
			check = false;
			for(int i=0;i<grid_cols;i++){
			
				for(int j=0;j<grid_rows;j++){
			
					if(swap(i+1,j+1,i+1,j+1,arr,auto_c,candy_grid)== true){
						check=true;
						print_grid(candy_grid);
					}
					if(swap(i+1,j+1,i+1,j+1,arr,auto_c,candy_grid)==true){
						print_grid(candy_grid);
						check=true;
					}
				}
			}
		}
	}
	bool check_consective_3(int r,int c,int r1,int c1,candy *arr[],bool auto_c,candy **candy_grid){
	
		if(c+1<grid_cols && c+2<grid_cols){
			if(candy_grid[r1][c1].get_id()==candy_grid[r1][c+1].get_id() && candy_grid[r1][c+1].get_id()==candy_grid[r1][c+2].get_id() && auto_c==false){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r1][c+1]=*arr[a];
				candy_grid[r1][c+2]=*arr[b];
				return true;
			}
			if(r1-1>=0){
			if(candy_grid[r1][c1].get_id()==candy_grid[r1-1][c+1].get_id() && candy_grid[r1-1][c+1].get_id()==candy_grid[r1-1][c+2].get_id() && auto_c!=false){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r1][c+1]=*arr[a];
				candy_grid[r1][c+2]=*arr[b];
				return true;
			}
		}
			if(r1+1<grid_rows){
			if(candy_grid[r1][c1].get_id()==candy_grid[r1+1][c+1].get_id() && candy_grid[r1+1][c+1].get_id()==candy_grid[r1+1][c+2].get_id() && auto_c!=false){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r1][c+1]=*arr[a];
				candy_grid[r1][c+2]=*arr[b];
				return true;
			}
			}
		}
		if(c+2<grid_cols && c+3<grid_cols && auto_c!=false){
			if(candy_grid[r][c].get_id()==candy_grid[r1][c+2].get_id() && candy_grid[r1][c+2].get_id()==candy_grid[r1][c+3].get_id()){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r1][c+1]=*arr[a];
				candy_grid[r1][c+2]=*arr[b];
				return true;
			}
		}
		
		if(c-1>=0 && c-2 >=0){
			if(candy_grid[r1][c1].get_id()==candy_grid[r1][c-1].get_id() && candy_grid[r1][c-1].get_id()==candy_grid[r1][c-2].get_id() && auto_c==false){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r1][c-1]=*arr[a];
				candy_grid[r1][c-2]=*arr[b];
				return true;
			}
			if(r1+1<grid_rows){
			if(candy_grid[r1][c1].get_id()==candy_grid[r1+1][c-1].get_id() && candy_grid[r1+1][c-1].get_id()==candy_grid[r1+1][c-2].get_id() && auto_c!=false){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r1][c-1]=*arr[a];
				candy_grid[r1][c-2]=*arr[b];
				return true;
			}
			}
			if(r1-1>=0){
			if(candy_grid[r1][c1].get_id()==candy_grid[r1-1][c-1].get_id() && candy_grid[r1-1][c-1].get_id()==candy_grid[r1-1][c-2].get_id() && auto_c!=false){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r1][c-1]=*arr[a];
				candy_grid[r1][c-2]=*arr[b];
				return true;
			}
			}
		}
		if(c-3>=0 && c-2 >=0 && auto_c!=false){
		 if(candy_grid[r1][c1].get_id()==candy_grid[r][c1-2].get_id() && candy_grid[r][c1-2].get_id()==candy_grid[r][c1-3].get_id()){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r1][c-1]=*arr[a];
				candy_grid[r1][c-2]=*arr[b];
				return true;
			}
		}
		

		if(r+1<grid_rows && r+2<grid_rows){
			if(candy_grid[r1][c1].get_id()==candy_grid[r+1][c].get_id() && candy_grid[r+1][c].get_id()==candy_grid[r+2][c].get_id() && auto_c==false){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r+1][c]=*arr[a];
				candy_grid[r+2][c]=*arr[b];
				return true;
			}
			if(c+1<grid_cols){
			if(candy_grid[r1][c1].get_id()==candy_grid[r+1][c+1].get_id() && candy_grid[r+1][c+1].get_id()==candy_grid[r+2][c+1].get_id() && auto_c!=false){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r+1][c]=*arr[a];
				candy_grid[r+2][c]=*arr[b];
				return true;
			}
			}
			if(c-1>=0){
			if(candy_grid[r1][c1].get_id()==candy_grid[r+1][c-1].get_id() && candy_grid[r+1][c-1].get_id()==candy_grid[r+2][c-1].get_id() && auto_c!=false){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r+1][c]=*arr[a];
				candy_grid[r+2][c]=*arr[b];
				return true;
			}
			}
		}
		if(r+3<grid_rows && r+2<grid_rows && auto_c!=false){
		if(candy_grid[r1][c1].get_id()==candy_grid[r1+2][c].get_id() && candy_grid[r1+3][c].get_id()==candy_grid[r1+2][c].get_id()){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r+1][c]=*arr[a];
				candy_grid[r+2][c]=*arr[b];
				return true;
			}
		}
		
		if(r-1>=0 && r-2>=0){

			 if(candy_grid[r1][c1].get_id()==candy_grid[r-1][c].get_id() && candy_grid[r-1][c].get_id()==candy_grid[r-2][c].get_id() && auto_c==false){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r-1][c]=*arr[a];
				candy_grid[r-2][c]=*arr[b];
				return true;
			}
			 if(c+1<grid_cols){
			 if(candy_grid[r1][c1].get_id()==candy_grid[r-1][c+1].get_id() && candy_grid[r-1][c+1].get_id()==candy_grid[r-2][c+1].get_id() && auto_c!=false){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r-1][c]=*arr[a];
				candy_grid[r-2][c]=*arr[b];
				return true;
			}
			 }
			 if(c-1>=0){
			 if(candy_grid[r1][c1].get_id()==candy_grid[r-1][c-1].get_id() && candy_grid[r-1][c-1].get_id()==candy_grid[r-2][c-1].get_id() && auto_c!=false){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r-1][c]=*arr[a];
				candy_grid[r-2][c]=*arr[b];
				return true;
			}
			 }
		}
		if(r-3>=0 && r-2>=0 && auto_c!=false){
			 if(candy_grid[r1][c1].get_id()==candy_grid[r1-3][c].get_id() && candy_grid[r1-3][c].get_id()==candy_grid[r1-2][c].get_id()){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r-1][c]=*arr[a];
				candy_grid[r-2][c]=*arr[b];
				return true;
			}
		}
		if(r-1>=0 && r-2>=0 && c+1<grid_cols && c+2<grid_cols && auto_c!=false){

			 if(candy_grid[r1][c1].get_id()==candy_grid[r-1][c+1].get_id() && candy_grid[r-1][c+1].get_id()==candy_grid[r-2][c+2].get_id()){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r-1][c]=*arr[a];
				candy_grid[r-2][c]=*arr[b];
				return true;
			}
		}
		if(r-1>=0 && r-2>=0 && c-1>=0 && c-2>=0 && auto_c!=false){

			 if(candy_grid[r1][c1].get_id()==candy_grid[r-1][c-1].get_id() && candy_grid[r-1][c-1].get_id()==candy_grid[r-2][c-2].get_id()){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r-1][c]=*arr[a];
				candy_grid[r-2][c]=*arr[b];
				return true;
			}
		}
		if(r+1<grid_cols && r+2<grid_cols && c+1<grid_cols && c+2<grid_cols && auto_c!=false){

			 if(candy_grid[r1][c1].get_id()==candy_grid[r+1][c+1].get_id() && candy_grid[r+1][c+1].get_id()==candy_grid[r+2][c+2].get_id()){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r-1][c]=*arr[a];
				candy_grid[r-2][c]=*arr[b];
				return true;
			}
		}
		if(r+1<grid_cols && r+2<grid_cols &&c-1 >=0 && c-2>=0 && auto_c!=false){

			 if(candy_grid[r1][c1].get_id()==candy_grid[r+1][c-1].get_id() && candy_grid[r+1][c-1].get_id()==candy_grid[r+2][c-2].get_id()){
				int a=(rand()%6);
				int b=(rand()%6);
				candy_grid[r-1][c]=*arr[a];
				candy_grid[r-2][c]=*arr[b];
				return true;
			}
		}
		return false;
	}
	void place_candy(int r,int c,int r1,int c1,candy **candy_grid){
		
		candy temp=candy_grid[r][c];
		candy_grid[r][c]=candy_grid[r1][c1];
		candy_grid[r1][c1]=temp;
		
	}
	void big_candy(int r1,int c1,candy *arr[],candy **candy_grid){
	
		int x=candy_grid[r1][c1].get_id();
		arr[x-1]->enlarge();
		update_score(r1,c1,candy_grid);
	}
	player(int i,int c,int r){
	
		id=i;
		score=0;
		grid_cols=c;
		grid_rows=r;
	
	}
};