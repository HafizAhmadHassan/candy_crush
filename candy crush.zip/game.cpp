#include "player.h"
#include "fstream"
#include <iostream>

using namespace std;
void saveGame(candy **candy_grid,int row,int col,int score){

	ofstream fout("candy crush.txt");
	for(int i=0;i<row;i++){
		for(int j=0;j<col;j++){
			fout<<candy_grid[i][j].get_id();	
		}
	}
	ofstream fouf("RCS.txt");
	fouf<<row<<","<<col<<",";
	fouf<<score<<",";
}
int loadGame(int arr[],int &row,int &col,candy *candies[]){

	char ch;
	int count=0,score=0;
	ifstream fif("RCS.txt");
	while(!fif.eof()){
	char n[20]="\0";
	fif.get(ch);

		for(int k=0;k<20 && ch!=',';k++){
			count++;
			n[k]=ch;
			fif.get(ch);
		}
		int mul=1;
		for(int k=count-1;k>=0;k--){
		row=mul*(n[k]-48)+row;
		mul*=10;
		n[k]='\0';
		}

		fif.get(ch);
		count=0;
		for(int k=0;k<20 && ch!=',';k++){
			count++;
			n[k]=ch;
			fif.get(ch);
		}
		mul=1;
		for(int k=count-1;k>=0;k--){
		col=mul*(n[k]-48)+col;
		mul*=10;
		n[k]='\0';

		}
		count=0;
		fif.get(ch);
		for(int k=0;k<20 && ch!=',';k++){
			count++;
			n[k]=ch;
			fif.get(ch);
		}
		 mul=1;
		for(int k=count-1;k>=0;k--){
		score=mul*(n[k]-48)+score;
		mul*=10;
		n[k]='\0';
	}
		fif.get(ch);
	}
	
	
	int f=-1;
	ifstream fin("candy crush.txt");
	while( !fin.eof() ){
		
		f++;
		arr[f]=fin.get()-48;
	}
	
	return score;
}
int main(){

	int arrr[256];
	int cc;
	cout<<"MENU\n\n\n1.Start New Game\n2.Load Game\n3.Exit\n";
	cin>>cc;
	while(cc!=3){
		candy *candies[6];
		int Grow=0,Gcol=0;
		if(cc==1){
		cout<<"Enter the rows of the grid.\n";
		cin>>Grow;
		cout<<"Enter the coloumns of the grid.\n";
		cin>>Gcol;
		}
		int row=Grow,col=Gcol;
		orange o(1,5,0);
		strawberry s(2,4,0);
		lemon l(3,1,0);
		chocolate c(4,5,0);
		special_strawberry ss(5,6,4);
		special_orange so(6,4,3);
		candies[0]=&o;
		candies[1]=&s;
		candies[2]=&l;
		candies[3]=&c;
		candies[4]=&ss;
		candies[5]=&so;
		candy **candy_grid=new candy*[Grow];
		for(int i=0;i<Grow;i++){
			candy_grid[i]=new candy[Gcol];
		}
		for(int i=0;i<Grow;i++){
			for(int j=0;j<Gcol;j++){
			
				int a=(rand()%6);
				candy_grid[i][j]=*candies[a];
			}
		}
	
		
		if(cc==2){
		int sx=loadGame(arrr,Grow,Gcol,candies);
	
		candy_grid=new candy*[Grow];
		for(int i=0;i<Grow;i++){
			candy_grid[i]=new candy[Gcol];
		}
		
		int m=0;
		for(int i=0;i<Grow;i++){
			for(int j=0;j<Gcol;j++){
			
				candy_grid[i][j]=*candies[arrr[m]-1];	
				m++;
			}
		}
		player p1(1,Gcol,Grow);
		p1.set_score (sx);
		p1.print_grid(candy_grid);

		}
		player p1(1,Gcol,Grow);

		int i=0;
		p1.print_grid(candy_grid);
		p1.auto_check(1,1,1,1,candies,false,candy_grid);
		while(true){
	
			int row2,col2;
			cout<<"Enter source row\n";
			cin>>row;
			if(row==-1)
				break;
			cout<<"Enter source coloumn\n";
			cin>>col;
			if(col==-1)
				break;
			cout<<"Enter destination row\n";
			cin>>row2;
			if(row2==-1)
				break;
			cout<<"Enter destination coloumn\n";
			cin>>col2;
			if(col2==-1)
				break;
			bool swapping=p1.swap(row,col,row2,col2,candies,true,candy_grid);
			if(swapping == true){
			
				p1.print_grid(candy_grid);
		
				cout<<endl<<endl<<"Score: "<<p1.get_score()<<endl<<endl;
			}
			else
				cout<<"Invalid move.\n\n";
			p1.auto_check(1,1,1,1,candies,false,candy_grid);
		}
		cout<<"Do you want to save before quitting?\n1.Yes\n2.No\n";
		int w;
		cin>>w;
		if(w==1)
			saveGame(candy_grid,Grow,Gcol,p1.get_score());
		system("cls");
		cout<<"Want to play again ?\n\n1.Yes\n2.No\n";
		cin>>w;
		if(w==1)
			cc=3;
		else
			break;
	}
}